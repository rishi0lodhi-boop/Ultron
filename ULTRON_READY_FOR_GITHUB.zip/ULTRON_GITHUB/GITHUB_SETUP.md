# ULTRON - GitHub Actions Build Setup

**Automatic APK Building on GitHub Cloud** ☁️

---

## 🚀 **Quick Setup (5 Minutes)**

### **Step 1: Create GitHub Account** (Skip if you have one)
```
https://github.com/signup
Sign up → Verify email
```

### **Step 2: Create New Repository**
```
1. Login to GitHub
2. Click "+" icon → New repository
3. Name: ULTRON
4. Description: AI Assistant App
5. Public (free)
6. Click "Create repository"
```

### **Step 3: Upload This Entire Folder to GitHub**

#### **Option A: Using GitHub Web Interface** (Easiest)
```
1. Open your ULTRON repository
2. Click "Add file" → "Upload files"
3. Drag & drop THIS ENTIRE ULTRON_GITHUB folder contents
4. Commit files
```

#### **Option B: Using Git Command** (Advanced)
```bash
git clone https://github.com/YOUR_USERNAME/ULTRON.git
cd ULTRON
# Copy all files from this folder here
git add .
git commit -m "Initial ULTRON setup"
git push origin main
```

---

## ⚙️ **What Gets Uploaded**

The GitHub Actions workflow will automatically:

✅ Set up JDK 11
✅ Download dependencies (gradle)
✅ Compile Kotlin code
✅ Build Debug APK
✅ Upload APK as artifact
✅ Make APK downloadable

---

## 📥 **Download APK After Build**

### **Step 1: Push Files to GitHub**
Once you upload all files to GitHub, the build automatically starts!

### **Step 2: Check Build Status**
```
1. Go to your ULTRON repository
2. Click "Actions" tab
3. See "Build ULTRON APK" workflow running
4. Wait 5-10 minutes ⏳
```

### **Step 3: Get Green Checkmark ✅**
When the workflow completes successfully:
```
Status will show: ✅ Build ULTRON APK succeeded
```

### **Step 4: Download APK**
```
1. Click on the successful workflow run
2. Scroll down to "Artifacts" section
3. Click "ULTRON-Debug-APK"
4. Download .apk file
```

### **Step 5: Install on Phone**
```
1. Connect phone to computer
2. Transfer APK file
3. Or email to yourself
4. Open file manager on phone
5. Tap APK file
6. Install
7. DONE! 🎉
```

---

## 📂 **Project Structure**

```
ULTRON/
├── .github/workflows/
│   └── build.yml                    ← Automatic build instructions
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── java/com/ultron/assistant/
│       │   ├── MainActivity.kt
│       │   ├── OpenAIClient.kt
│       │   ├── SpeechManager.kt
│       │   ├── TTSManager.kt
│       │   ├── WebSearchManager.kt
│       │   ├── PhoneActionRouter.kt
│       │   └── PermissionManager.kt
│       ├── res/
│       │   ├── layout/activity_main.xml
│       │   ├── values/
│       │   └── drawable/
│       └── AndroidManifest.xml
├── gradle/
│   └── wrapper/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
└── README_ANDROIDIDE.md
```

---

## 🎯 **Build Workflow Breakdown**

The `.github/workflows/build.yml` file does:

```yaml
1. Checkout code from GitHub
2. Install JDK 11 (automatic)
3. Make gradlew executable
4. Run: ./gradlew assembleDebug
5. Upload APK artifact
6. Make available for download
```

**That's it!** No manual steps needed!

---

## ✅ **Checklist**

- [ ] GitHub account created
- [ ] ULTRON repository created
- [ ] All files uploaded to GitHub
- [ ] `.github/workflows/build.yml` exists in repo
- [ ] Workflow shows "✅ passed" in Actions tab
- [ ] APK downloaded
- [ ] APK installed on phone

---

## 🚨 **Troubleshooting**

### **Build Failed ❌**
1. Check Actions tab → See error message
2. Common issues:
   - Files not uploaded properly
   - Missing `.github/workflows/build.yml`
   - Gradle sync failed

**Solution:** Re-upload all files carefully

### **Build Stuck ⏳**
- GitHub build usually takes 5-10 minutes
- Wait longer (server might be slow)
- Check Actions tab for status

### **APK Not Downloading**
- Scroll down in workflow run page
- Look for "Artifacts" section
- If missing, build failed - check errors

---

## 🔐 **Security Notes**

⚠️ **IMPORTANT:**
- Do NOT put real OpenAI API key in `gradle.properties`
- GitHub repository is public (if set public)
- Anyone can see your code
- API key should be added later on phone

**Safe practice:**
```
1. Build APK on GitHub (no API key)
2. Download APK
3. Configure API key IN APP on phone
```

---

## 📱 **After APK Download**

1. **Install APK on phone:**
   ```
   Open APK file → Install
   ```

2. **Grant Permissions:**
   - Microphone access (for voice)
   - Storage access (if needed)

3. **Configure OpenAI API Key:**
   - Open ULTRON app
   - See error: "API key not configured"
   - Check `README_ANDROIDIDE.md` for setup

4. **Use ULTRON!**
   - Type messages
   - Use microphone
   - Enable speaker

---

## 🆘 **Need Help?**

If workflow fails:
1. Check error message in Actions tab
2. Common: Java path, Gradle cache
3. Solution: Click "Re-run jobs" button

---

## 🎉 **You're Done!**

GitHub will automatically build APK every time you:
- Push code
- Manually trigger workflow
- Create pull request

**Your APK is always ready to download!** ✨

---

**Happy Building! 🚀**

Last Updated: 2026-10-07
