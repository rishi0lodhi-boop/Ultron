package com.ultron.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/**
 * TTSManager: Handles Android Text-to-Speech
 * 
 * Supports: English, Hindi (when available), Hinglish
 * Includes safe initialization and fallback handling
 */
class TTSManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var speechRate = 1.0f
    private var onInitListener: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            try {
                // Try Hindi first, fall back to English
                val language = if (tts?.isLanguageAvailable(Locale("hi", "IN")) == TextToSpeech.LANG_AVAILABLE) {
                    tts?.language = Locale("hi", "IN")
                    Log.d("TTSManager", "Hindi TTS initialized")
                    Locale("hi", "IN")
                } else {
                    tts?.language = Locale.US
                    Log.d("TTSManager", "English TTS initialized")
                    Locale.US
                }

                // Set speech rate
                tts?.setSpeechRate(speechRate)
                
                // Try to prefer male voice
                preferMaleVoice()
                
                isReady = true
                onInitListener?.invoke()
            } catch (e: Exception) {
                Log.e("TTSManager", "Error initializing TTS", e)
                isReady = false
            }
        } else {
            Log.e("TTSManager", "TTS initialization failed with status: $status")
            isReady = false
        }
    }

    /**
     * Attempt to use a male voice if available
     */
    private fun preferMaleVoice() {
        try {
            // This is device-dependent; some devices may not have voice selection
            val voices = tts?.voices ?: return
            val maleVoice = voices.find { it.name.contains("male", ignoreCase = true) }
            if (maleVoice != null) {
                tts?.voice = maleVoice
                Log.d("TTSManager", "Male voice selected: ${maleVoice.name}")
            }
        } catch (e: Exception) {
            Log.w("TTSManager", "Could not select male voice: ${e.message}")
        }
    }

    /**
     * Speak the given text
     */
    fun speak(text: String) {
        if (!isReady || tts == null) {
            Log.w("TTSManager", "TTS not ready")
            return
        }

        if (text.isEmpty()) {
            return
        }

        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
        } catch (e: Exception) {
            Log.e("TTSManager", "Error speaking text", e)
        }
    }

    /**
     * Speak text with language selection
     */
    fun speakWithLanguage(text: String, language: String = "hi-IN") {
        if (!isReady || tts == null) {
            Log.w("TTSManager", "TTS not ready")
            return
        }

        try {
            when (language) {
                "hi-IN" -> tts?.language = Locale("hi", "IN")
                "en-IN" -> tts?.language = Locale("en", "IN")
                "en-US" -> tts?.language = Locale.US
                else -> tts?.language = Locale.US
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
        } catch (e: Exception) {
            Log.e("TTSManager", "Error speaking text with language: $language", e)
        }
    }

    /**
     * Set speech rate (0.5f to 2.0f)
     */
    fun setSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(speechRate)
    }

    /**
     * Stop speaking
     */
    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e("TTSManager", "Error stopping TTS", e)
        }
    }

    /**
     * Check if TTS is ready
     */
    fun isInitialized(): Boolean = isReady

    /**
     * Set initialization callback
     */
    fun setOnInitListener(listener: () -> Unit) {
        onInitListener = listener
        if (isReady) {
            listener.invoke()
        }
    }

    /**
     * Clean up resources
     */
    fun destroy() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isReady = false
        } catch (e: Exception) {
            Log.e("TTSManager", "Error destroying TTS", e)
        }
    }
}
