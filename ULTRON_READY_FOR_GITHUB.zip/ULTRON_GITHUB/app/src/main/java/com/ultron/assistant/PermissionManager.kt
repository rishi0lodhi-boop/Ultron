package com.ultron.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * PermissionManager: Handles Android runtime permissions
 * 
 * Permissions are only requested when needed, not on app startup.
 * Uses Android runtime permission framework (API 23+).
 */
class PermissionManager(private val context: Context) {

    /**
     * Check if RECORD_AUDIO permission is granted
     */
    fun hasMicrophonePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true // Permission granted by default on older Android versions
        }
    }

    /**
     * Check if INTERNET permission is available
     * Note: INTERNET is a normal permission, always granted if declared in manifest
     */
    fun hasInternetPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.INTERNET
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Microphone permission constant for request callbacks
     */
    companion object {
        const val PERMISSION_REQUEST_MICROPHONE = 101
        const val PERMISSION_REQUEST_CODE = 102
    }
}
