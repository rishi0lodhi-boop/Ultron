package com.ultron.assistant

import android.content.Context
import android.content.Intent
import android.os.Build
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * SpeechManager: Handles Android voice input via SpeechRecognizer
 * 
 * Supports: English (en-IN, en-US), Hindi (hi-IN), Hinglish
 * Provides safe error handling and graceful fallback
 */
class SpeechManager(private val context: Context) : RecognitionListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var onResultListener: ((String) -> Unit)? = null
    private var onErrorListener: ((String) -> Unit)? = null

    init {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer?.setRecognitionListener(this)
        } else {
            Log.w("SpeechManager", "Speech recognition not available on this device")
        }
    }

    /**
     * Start listening for voice input
     * Requests Hinglish/English/Hindi language
     */
    fun startListening(language: String = "hi-IN") {
        if (speechRecognizer == null) {
            onErrorListener?.invoke("Speech recognition service unavailable")
            return
        }

        try {
            val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_PROMPT,
                    "Say something..."
                )
                putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error starting speech recognition", e)
            onErrorListener?.invoke(e.message ?: "Unknown error")
        }
    }

    /**
     * Stop listening
     */
    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error stopping speech recognition", e)
        }
    }

    /**
     * Cancel speech recognition
     */
    fun cancel() {
        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error canceling speech recognition", e)
        }
    }

    /**
     * Set callback for successful recognition results
     */
    fun setOnResultListener(listener: (String) -> Unit) {
        onResultListener = listener
    }

    /**
     * Set callback for errors
     */
    fun setOnErrorListener(listener: (String) -> Unit) {
        onErrorListener = listener
    }

    /**
     * RecognitionListener implementation
     */
    override fun onReadyForSpeech(params: android.os.Bundle?) {
        Log.d("SpeechManager", "Ready for speech")
    }

    override fun onBeginningOfSpeech() {
        Log.d("SpeechManager", "Beginning of speech detected")
    }

    override fun onRmsChanged(rmsdB: Float) {
        // RMS level changed
    }

    override fun onBufferReceived(buffer: ByteArray?) {
        // Buffer received
    }

    override fun onEndOfSpeech() {
        Log.d("SpeechManager", "End of speech")
    }

    override fun onError(error: Int) {
        val errorMessage = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
            SpeechRecognizer.ERROR_NETWORK -> "Network error"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
            SpeechRecognizer.ERROR_SERVER -> "Server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
            else -> "Unknown error: $error"
        }
        Log.e("SpeechManager", "Speech recognition error: $errorMessage")
        onErrorListener?.invoke(errorMessage)
    }

    override fun onResults(results: android.os.Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val recognizedText = matches[0]
            Log.d("SpeechManager", "Recognized: $recognizedText")
            onResultListener?.invoke(recognizedText)
        } else {
            onErrorListener?.invoke("No speech recognized")
        }
    }

    override fun onPartialResults(partialResults: android.os.Bundle?) {
        // Partial results available
    }

    override fun onEvent(eventType: Int, params: android.os.Bundle?) {
        // Event received
    }

    /**
     * Clean up resources
     */
    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error destroying speech recognizer", e)
        }
    }
}
