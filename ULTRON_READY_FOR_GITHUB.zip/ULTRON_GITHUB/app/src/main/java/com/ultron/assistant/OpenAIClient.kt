package com.ultron.assistant

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * OpenAIClient: Communicates with OpenAI API
 * 
 * Uses the OpenAI Messages API (current implementation).
 * Supports conversation context maintenance during the session.
 * 
 * Configuration:
 * - API Key: Must be set via BuildConfig.OPENAI_API_KEY or local property
 * - Model: Must be set via BuildConfig.OPENAI_MODEL
 * 
 * IMPORTANT: API keys are NEVER hard-coded in source.
 * Set them in gradle.properties or BuildConfig.
 */
class OpenAIClient {

    private val gson = Gson()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiUrl = "https://api.openai.com/v1/chat/completions"
    private var apiKey: String? = null
    private var model: String? = null
    
    // Maintain conversation history for context
    private val conversationHistory = mutableListOf<ConversationMessage>()
    private val maxHistorySize = 10 // Keep last 10 messages for context

    /**
     * Initialize client with API credentials
     */
    fun initialize(apiKey: String, model: String) {
        this.apiKey = apiKey
        this.model = model
        Log.d("OpenAIClient", "Client initialized with model: $model")
    }

    /**
     * Check if client is properly configured
     */
    fun isConfigured(): Boolean {
        return !apiKey.isNullOrEmpty() && !model.isNullOrEmpty()
    }

    /**
     * Get configuration status message
     */
    fun getConfigurationStatus(): String {
        return when {
            apiKey.isNullOrEmpty() -> "ERROR: OpenAI API key not configured"
            model.isNullOrEmpty() -> "ERROR: OpenAI model not configured"
            else -> "OK: Configured with model $model"
        }
    }

    /**
     * Send a message to OpenAI and get response
     * Maintains conversation context
     */
    suspend fun sendMessage(userMessage: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (!isConfigured()) {
                return@withContext Result.failure(
                    Exception("Client not configured. ${getConfigurationStatus()}")
                )
            }

            // Add user message to history
            conversationHistory.add(ConversationMessage("user", userMessage))

            // Build request payload
            val messages = conversationHistory.map {
                JsonObject().apply {
                    addProperty("role", it.role)
                    addProperty("content", it.content)
                }
            }

            val payload = JsonObject().apply {
                addProperty("model", model)
                add("messages", gson.toJsonTree(messages))
                addProperty("temperature", 0.7)
                addProperty("max_tokens", 500)
            }

            val requestBody = payload.toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(apiUrl)
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json")
                .post(requestBody)
                .build()

            Log.d("OpenAIClient", "Sending request to OpenAI API")
            
            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    Exception("API error: ${response.code} - ${response.message}")
                )
            }

            val responseBody = response.body?.string() ?: ""
            val responseJson = gson.fromJson(responseBody, JsonObject::class.java)

            // Extract assistant message
            val assistantMessage = responseJson
                .getAsJsonArray("choices")
                ?.get(0)
                ?.asJsonObject
                ?.getAsJsonObject("message")
                ?.get("content")
                ?.asString
                ?: return@withContext Result.failure(Exception("Invalid API response"))

            // Add assistant response to history
            conversationHistory.add(ConversationMessage("assistant", assistantMessage))

            // Trim history if too long
            if (conversationHistory.size > maxHistorySize) {
                conversationHistory.removeAt(0)
            }

            Log.d("OpenAIClient", "Response received successfully")
            Result.success(assistantMessage)

        } catch (e: IOException) {
            Log.e("OpenAIClient", "Network error: ${e.message}")
            Result.failure(Exception("Network error: ${e.message}"))
        } catch (e: Exception) {
            Log.e("OpenAIClient", "Error communicating with API: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Clear conversation history
     */
    fun clearHistory() {
        conversationHistory.clear()
        Log.d("OpenAIClient", "Conversation history cleared")
    }

    /**
     * Get current conversation history size
     */
    fun getHistorySize(): Int = conversationHistory.size

    /**
     * Data class for conversation messages
     */
    private data class ConversationMessage(
        val role: String, // "user" or "assistant"
        val content: String
    )

    /**
     * Result wrapper for success/failure handling
     */
    sealed class Result<out T> {
        data class Success<T>(val data: T) : Result<T>()
        data class Failure(val exception: Exception) : Result<Nothing>()

        fun <R> map(transform: (T) -> R): Result<R> = when (this) {
            is Success -> Success(transform(data))
            is Failure -> Failure(exception)
        }

        suspend fun onSuccess(block: suspend (T) -> Unit): Result<T> {
            if (this is Success) block(data)
            return this
        }

        suspend fun onFailure(block: suspend (Exception) -> Unit): Result<T> {
            if (this is Failure) block(exception)
            return this
        }

        fun getOrNull(): T? = (this as? Success)?.data
        fun getOrThrow(): T = (this as Success).data
    }
}
