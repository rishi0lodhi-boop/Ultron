package com.ultron.assistant

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * MainActivity: Main ULTRON Assistant Interface
 * 
 * Features:
 * - Chat interface with ULTRON
 * - Voice input (microphone)
 * - Text-to-speech output (speaker)
 * - Message input field
 * - System status display
 * - Web search status
 * - Clear conversation button
 */
class MainActivity : AppCompatActivity() {

    // UI Components
    private lateinit var chatArea: TextView
    private lateinit var userInput: EditText
    private lateinit var sendButton: Button
    private lateinit var micButton: Button
    private lateinit var speakerButton: Button
    private lateinit var clearButton: Button
    private lateinit var systemStatus: TextView
    private lateinit var webSearchStatus: TextView

    // Managers
    private lateinit var openAIClient: OpenAIClient
    private lateinit var speechManager: SpeechManager
    private lateinit var ttsManager: TTSManager
    private lateinit var webSearchManager: WebSearchManager
    private lateinit var phoneActionRouter: PhoneActionRouter
    private lateinit var permissionManager: PermissionManager

    // Coroutine scope
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    // State
    private var isListening = false
    private var lastResponse = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        initializeUI()

        // Initialize managers
        initializeManagers()

        // Set up event listeners
        setupEventListeners()

        Log.d("MainActivity", "ULTRON initialized successfully")
    }

    /**
     * Initialize UI components
     */
    private fun initializeUI() {
        chatArea = findViewById(R.id.chatArea)
        userInput = findViewById(R.id.userInput)
        sendButton = findViewById(R.id.sendButton)
        micButton = findViewById(R.id.micButton)
        speakerButton = findViewById(R.id.speakerButton)
        clearButton = findViewById(R.id.clearButton)
        systemStatus = findViewById(R.id.systemStatus)
        webSearchStatus = findViewById(R.id.webSearchStatus)

        updateSystemStatus("Ready")
    }

    /**
     * Initialize all managers
     */
    private fun initializeManagers() {
        // Initialize OpenAI Client
        openAIClient = OpenAIClient()
        
        // Try to get API credentials from BuildConfig or environment
        val apiKey = BuildConfig.OPENAI_API_KEY.ifEmpty {
            // Fallback: Check if user has set it manually
            null
        }
        
        val model = BuildConfig.OPENAI_MODEL.ifEmpty { "gpt-4-turbo" }

        if (!apiKey.isNullOrEmpty() && apiKey != "\"\"") {
            openAIClient.initialize(apiKey, model)
            updateSystemStatus("AI: Ready")
        } else {
            updateSystemStatus("AI: ${openAIClient.getConfigurationStatus()}")
        }

        // Initialize Speech Manager
        speechManager = SpeechManager(this)
        speechManager.setOnResultListener { recognizedText ->
            userInput.setText(recognizedText)
            isListening = false
            updateMicButtonUI()
            Log.d("MainActivity", "Speech recognized: $recognizedText")
        }
        
        speechManager.setOnErrorListener { error ->
            isListening = false
            updateMicButtonUI()
            showError("Speech Error: $error")
            Log.e("MainActivity", "Speech error: $error")
        }

        // Initialize TTS Manager
        ttsManager = TTSManager(this)
        ttsManager.setOnInitListener {
            Log.d("MainActivity", "TTS initialized")
        }

        // Initialize Web Search Manager
        webSearchManager = WebSearchManager()
        updateWebSearchStatus()

        // Initialize Phone Action Router
        phoneActionRouter = PhoneActionRouter(this)
        phoneActionRouter.setConfirmationListener { message, action ->
            showConfirmationDialog(message, action)
        }

        // Initialize Permission Manager
        permissionManager = PermissionManager(this)
    }

    /**
     * Set up button click listeners
     */
    private fun setupEventListeners() {
        sendButton.setOnClickListener {
            val message = userInput.text.toString().trim()
            if (message.isNotEmpty()) {
                sendMessage(message)
            }
        }

        micButton.setOnClickListener {
            if (!isListening) {
                if (permissionManager.hasMicrophonePermission()) {
                    startListening()
                } else {
                    requestMicrophonePermission()
                }
            } else {
                stopListening()
            }
        }

        speakerButton.setOnClickListener {
            if (lastResponse.isNotEmpty()) {
                ttsManager.speak(lastResponse)
            } else {
                showError("No response to speak")
            }
        }

        clearButton.setOnClickListener {
            clearConversation()
        }

        // Allow Enter key to send message
        userInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_ENTER && 
                event.action == android.view.KeyEvent.ACTION_DOWN) {
                val message = userInput.text.toString().trim()
                if (message.isNotEmpty()) {
                    sendMessage(message)
                }
                return@setOnKeyListener true
            }
            false
        }
    }

    /**
     * Send message to ULTRON AI
     */
    private fun sendMessage(message: String) {
        userInput.text.clear()
        addMessageToChat("You: $message")

        // Check if web search is needed
        if (webSearchManager.needsWebSearch(message)) {
            addMessageToChat("Searching for current information...")
        }

        scope.launch {
            try {
                val result = openAIClient.sendMessage(message)
                
                result.onSuccess { response ->
                    lastResponse = response
                    addMessageToChat("ULTRON: $response")
                    
                    // Check if response suggests a phone action
                    if (response.contains("open", ignoreCase = true) ||
                        response.contains("call", ignoreCase = true) ||
                        response.contains("message", ignoreCase = true)) {
                        phoneActionRouter.routeCommand(message)
                    }
                }.onFailure { error ->
                    showError("Error: ${error.message}")
                    addMessageToChat("ULTRON: I encountered an error. ${error.message}")
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error sending message", e)
                showError("Exception: ${e.message}")
            }
        }
    }

    /**
     * Start voice recognition
     */
    private fun startListening() {
        if (permissionManager.hasMicrophonePermission()) {
            isListening = true
            updateMicButtonUI()
            speechManager.startListening("hi-IN") // Default: Hindi
            addMessageToChat("Listening...")
            Log.d("MainActivity", "Listening started")
        } else {
            requestMicrophonePermission()
        }
    }

    /**
     * Stop voice recognition
     */
    private fun stopListening() {
        isListening = false
        updateMicButtonUI()
        speechManager.stopListening()
        Log.d("MainActivity", "Listening stopped")
    }

    /**
     * Add message to chat display
     */
    private fun addMessageToChat(message: String) {
        val currentText = chatArea.text.toString()
        val newText = if (currentText == "ULTRON Assistant Ready. Listening for commands in English, Hindi, or Hinglish.") {
            message
        } else {
            "$currentText\n\n$message"
        }
        chatArea.text = newText
    }

    /**
     * Clear conversation
     */
    private fun clearConversation() {
        chatArea.text = "ULTRON Assistant Ready. Listening for commands in English, Hindi, or Hinglish."
        userInput.text.clear()
        openAIClient.clearHistory()
        lastResponse = ""
        Log.d("MainActivity", "Conversation cleared")
    }

    /**
     * Update system status display
     */
    private fun updateSystemStatus(status: String) {
        systemStatus.text = "System Status: $status"
    }

    /**
     * Update web search status display
     */
    private fun updateWebSearchStatus() {
        webSearchStatus.text = webSearchManager.getStatusMessage()
    }

    /**
     * Update microphone button UI based on listening state
     */
    private fun updateMicButtonUI() {
        micButton.text = if (isListening) "STOP" else "MIC"
        micButton.setBackgroundColor(
            if (isListening) resources.getColor(R.color.primary_red, null)
            else resources.getColor(R.color.dark_red, null)
        )
    }

    /**
     * Request microphone permission
     */
    private fun requestMicrophonePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.RECORD_AUDIO),
                PermissionManager.PERMISSION_REQUEST_MICROPHONE
            )
        }
    }

    /**
     * Handle permission results
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == PermissionManager.PERMISSION_REQUEST_MICROPHONE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening()
            } else {
                showError("Microphone permission denied")
            }
        }
    }

    /**
     * Show error message
     */
    private fun showError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    /**
     * Show confirmation dialog for sensitive actions
     */
    private fun showConfirmationDialog(message: String, action: Runnable) {
        AlertDialog.Builder(this)
            .setTitle("Confirm Action")
            .setMessage(message)
            .setPositiveButton("Yes") { _, _ -> action.run() }
            .setNegativeButton("No") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    /**
     * Clean up resources
     */
    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
        ttsManager.destroy()
        scope.cancel()
        Log.d("MainActivity", "ULTRON destroyed")
    }
}
