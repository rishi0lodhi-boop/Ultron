package com.ultron.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log

/**
 * PhoneActionRouter: Routes voice commands to Android intents
 * 
 * Examples:
 * - "open YouTube" -> com.google.android.youtube
 * - "open Maps" -> com.google.android.apps.maps
 * - "call 9876543210" -> Phone call (with confirmation)
 * - "open Google" -> Web search or browser
 * 
 * IMPORTANT: Calls and SMS require user confirmation before execution.
 * Never silently send SMS or make calls.
 */
class PhoneActionRouter(private val context: Context) {

    private var onConfirmationNeeded: ((String, Runnable) -> Unit)? = null

    /**
     * Set callback for actions requiring confirmation
     */
    fun setConfirmationListener(listener: (String, Runnable) -> Unit) {
        onConfirmationNeeded = listener
    }

    /**
     * Route a command to appropriate action
     */
    fun routeCommand(command: String) {
        val lowerCommand = command.lowercase()

        when {
            // YouTube
            lowerCommand.contains("youtube") || lowerCommand.contains("youtu") ->
                openApp("com.google.android.youtube", "https://www.youtube.com")

            // Google Maps
            lowerCommand.contains("maps") || lowerCommand.contains("location") ->
                openApp("com.google.android.apps.maps", "https://maps.google.com")

            // Google Search
            lowerCommand.contains("google search") || lowerCommand.contains("search") ->
                openBrowser("https://www.google.com")

            // Settings
            lowerCommand.contains("settings") ->
                openSettings()

            // Phone Call - Requires Confirmation
            lowerCommand.contains("call") ->
                handlePhoneCall(command)

            // SMS/Message - Requires Confirmation
            lowerCommand.contains("message") || lowerCommand.contains("sms") ->
                handleSMS(command)

            // Open Browser
            lowerCommand.contains("browser") ->
                openBrowser("https://www.google.com")

            else -> {
                Log.d("PhoneActionRouter", "No matching action for: $command")
            }
        }
    }

    /**
     * Open an app by package name
     * Falls back to browser if app not installed
     */
    private fun openApp(packageName: String, fallbackUrl: String) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                context.startActivity(intent)
                Log.d("PhoneActionRouter", "Opened app: $packageName")
            } else {
                Log.d("PhoneActionRouter", "App not installed: $packageName, opening browser instead")
                openBrowser(fallbackUrl)
            }
        } catch (e: Exception) {
            Log.e("PhoneActionRouter", "Error opening app: $packageName", e)
            openBrowser(fallbackUrl)
        }
    }

    /**
     * Open browser with URL
     */
    fun openBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
            Log.d("PhoneActionRouter", "Opened browser with URL: $url")
        } catch (e: Exception) {
            Log.e("PhoneActionRouter", "Error opening browser", e)
        }
    }

    /**
     * Open Android Settings
     */
    private fun openSettings() {
        try {
            val intent = Intent(android.provider.Settings.ACTION_SETTINGS)
            context.startActivity(intent)
            Log.d("PhoneActionRouter", "Opened Settings")
        } catch (e: Exception) {
            Log.e("PhoneActionRouter", "Error opening settings", e)
        }
    }

    /**
     * Handle phone call - REQUIRES USER CONFIRMATION
     * 
     * Example input: "call 9876543210"
     */
    private fun handlePhoneCall(command: String) {
        // Extract phone number from command
        val phoneNumber = extractPhoneNumber(command)
        
        if (phoneNumber.isEmpty()) {
            Log.d("PhoneActionRouter", "No phone number found in command: $command")
            return
        }

        val confirmationMessage = "Call $phoneNumber?"
        
        // Request confirmation from UI
        onConfirmationNeeded?.invoke(confirmationMessage) {
            // User confirmed - make the call
            try {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
                // NOTE: Requires android.permission.CALL_PHONE permission
                context.startActivity(intent)
                Log.d("PhoneActionRouter", "Call initiated to: $phoneNumber")
            } catch (e: Exception) {
                Log.e("PhoneActionRouter", "Error making call", e)
            }
        }
    }

    /**
     * Handle SMS - REQUIRES USER CONFIRMATION
     * 
     * Example input: "message 9876543210 hello"
     */
    private fun handleSMS(command: String) {
        val phoneNumber = extractPhoneNumber(command)
        
        if (phoneNumber.isEmpty()) {
            Log.d("PhoneActionRouter", "No phone number found in SMS command")
            return
        }

        val confirmationMessage = "Send SMS to $phoneNumber?"
        
        // Request confirmation from UI
        onConfirmationNeeded?.invoke(confirmationMessage) {
            // User confirmed - open SMS composer
            try {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phoneNumber"))
                context.startActivity(intent)
                Log.d("PhoneActionRouter", "SMS composer opened for: $phoneNumber")
            } catch (e: Exception) {
                Log.e("PhoneActionRouter", "Error opening SMS composer", e)
            }
        }
    }

    /**
     * Extract phone number from text
     * Simple pattern: looks for 10-digit numbers
     */
    private fun extractPhoneNumber(text: String): String {
        val phonePattern = "\\d{10}".toRegex()
        val match = phonePattern.find(text)
        return match?.value ?: ""
    }

    /**
     * Open URL
     */
    fun openURL(url: String) {
        val finalUrl = if (!url.startsWith("http")) "https://$url" else url
        openBrowser(finalUrl)
    }
}
