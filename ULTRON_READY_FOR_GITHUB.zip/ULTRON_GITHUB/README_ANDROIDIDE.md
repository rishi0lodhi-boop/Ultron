# ULTRON Assistant - AndroidIDE Build Guide

**ULTRON**: A futuristic AI-powered voice assistant for Android with OpenAI integration.

## 📋 Project Specifications

- **Language**: Kotlin + Android XML
- **Gradle**: 8.2
- **AGP**: 8.1.4
- **JDK**: Java 11 (Compatible with most Android phones)
- **SDK Level**: 34 (Target), 24 (Min)
- **Architecture**: Native Android with AndroidX

> **Note:** This is the JDK 11 version. If you have JDK 17+ available, use ULTRON_ANDROIDIDE_GRADLE_8_2.zip instead.

## 🚀 Quick Start

### Prerequisites

1. **AndroidIDE** installed on your Android phone
2. **JDK 11 or higher** (AndroidIDE will automatically detect available JDK)
3. **Internet connection** for Gradle sync and API calls
4. **OpenAI API Key** (from https://platform.openai.com)

> **JDK Compatibility:** This version works with JDK 11, 17, or any higher version. AndroidIDE will use whatever JDK is available.

### Step 1: Extract the Project

```bash
# On your Android phone, extract the ZIP file
# Navigate to your downloads or preferred location
unzip ULTRON_ANDROIDIDE_GRADLE_8_2.zip
```

### Step 2: Open in AndroidIDE

1. Open **AndroidIDE**
2. Tap **"Open Project"**
3. Navigate to the extracted **ULTRON** folder
4. Select it and tap **"Open"**

### Step 3: Configure JDK

1. In AndroidIDE, go to **Settings → Build Tools** or **SDK**
2. Ensure **any JDK version (11+)** is selected
3. This version is compatible with JDK 11, so if you have it installed, it will work
4. If no JDK is available, AndroidIDE will download one automatically

### Step 4: Gradle Sync

1. AndroidIDE will automatically detect the project
2. Tap **"Sync Project"** or **"Build → Sync Gradle"**
3. Wait for Gradle to download dependencies (may take 2-5 minutes on first run)
4. Ensure sync completes without errors

### Step 5: Configure OpenAI API Key

**Option A: Via gradle.properties (Recommended)**

1. Open `gradle.properties` in AndroidIDE
2. Find the comment: `# OPENAI_API_KEY=your_api_key_here`
3. Uncomment and add your key:
   ```properties
   OPENAI_API_KEY=sk-...your-actual-key...
   OPENAI_MODEL=gpt-4-turbo
   ```
4. Save the file
5. Re-sync Gradle

**Option B: Runtime Configuration**

1. Build and run the app (see Step 6)
2. The app will show a configuration error
3. Modify `MainActivity.kt` to set:
   ```kotlin
   openAIClient.initialize("your-api-key", "gpt-4-turbo")
   ```

### Step 6: Build Debug APK

1. In AndroidIDE, tap **"Build"**
2. Select **"Build Debug APK"**
3. Wait for the build to complete (may take 1-2 minutes)
4. If successful, you'll see: **"Build completed successfully"**

### Step 7: Install APK

1. After build succeeds, tap **"Run"** or **"Install APK"**
2. AndroidIDE will install the APK on your device
3. Launch **ULTRON** from your app drawer

### Step 8: Grant Permissions

On first launch:
1. ULTRON will request **Microphone** permission
2. Tap **"Allow"** to enable voice input
3. System will show configuration status

## ✨ Features Included

✅ **AI Assistant**
- OpenAI GPT-4 integration
- Conversation context memory
- Multi-language support (English, Hindi, Hinglish)

✅ **Voice Input**
- Speech-to-Text recognition
- Hindi language support (hi-IN)
- English language support (en-IN, en-US)
- Real-time transcription

✅ **Text-to-Speech**
- Android TTS engine
- Hindi voice support
- English voice support
- Male voice preference
- Configurable speech rate

✅ **User Interface**
- Futuristic red/black theme
- Chat message display
- Real-time status updates
- Message input field
- Control buttons (Send, Microphone, Speaker, Clear)

✅ **Phone Actions**
- Open apps (YouTube, Maps, Browser)
- Safe intent routing
- Error handling

✅ **Permission Management**
- Runtime permission handling
- Least-privilege principle
- User-friendly prompts

## 🔒 Security & Privacy

- **No API key in source code** (use gradle.properties)
- **No permanent data storage**
- **No tracking or analytics**
- **No background surveillance**
- **Least-privilege permissions**
- **User confirmation required** for sensitive actions (calls, SMS)

## 📱 UI Controls

| Button | Function |
|--------|----------|
| **MIC** | Start/Stop voice input |
| **SEND** | Send text message to ULTRON |
| **SPEAK** | Play last response via TTS |
| **CLEAR** | Clear conversation history |

**Status Indicators:**
- 🟢 Green: Ready/Success
- 🟡 Yellow: Warning
- 🔴 Red: Error

## 🔧 Troubleshooting

### Build Errors

**Error: "Gradle sync failed"**
- Solution: Check internet connection, ensure JDK 17 is installed
- Try: **Build → Clean Project** then **Sync Gradle**

**Error: "Failed to download Gradle"**
- Solution: Check WiFi connection, Gradle 8.2 requires ~100MB download
- Try: Use mobile data or WiFi with good signal

**Error: "Unsupported class-file format"**
- Solution: Ensure JDK 17 is selected in Build Tools
- Check: Settings → Build Tools → Verify JDK version

### Runtime Errors

**"OpenAI API key not configured"**
- Solution: Set OPENAI_API_KEY in gradle.properties
- Rebuild and reinstall APK

**"Speech recognition not available"**
- Solution: This is device-dependent; Google Speech Recognizer may not be available on all devices
- Workaround: Use text input instead of microphone

**"Text-to-speech unavailable"**
- Solution: Install a TTS engine (e.g., Google Text-to-Speech)
- Go to: Android Settings → Accessibility → Text-to-Speech

**Network/API Timeout**
- Solution: Check internet connection
- Verify: OpenAI API status at https://status.openai.com

## 📚 Project Structure

```
ULTRON/
├── settings.gradle.kts       # Project settings
├── build.gradle.kts          # Root build config
├── gradle.properties         # Gradle & API config
│
├── app/
│   ├── build.gradle.kts      # App build config
│   │
│   └── src/main/
│       ├── AndroidManifest.xml
│       │
│       ├── java/com/ultron/assistant/
│       │   ├── MainActivity.kt           # Main activity
│       │   ├── OpenAIClient.kt           # OpenAI API client
│       │   ├── SpeechManager.kt          # Speech recognition
│       │   ├── TTSManager.kt             # Text-to-speech
│       │   ├── WebSearchManager.kt       # Web search interface
│       │   ├── PhoneActionRouter.kt      # Intent routing
│       │   └── PermissionManager.kt      # Permission handling
│       │
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/
│           │   ├── strings.xml
│           │   ├── colors.xml
│           │   └── themes.xml
│           └── drawable/
│               └── ultron_background.xml
```

## 🌐 API Configuration

### OpenAI API Setup

1. **Get API Key:**
   - Visit https://platform.openai.com
   - Sign up or login
   - Create API key in "API keys" section
   - Copy the key (starts with `sk-`)

2. **Set API Key in ULTRON:**
   - Edit `gradle.properties`
   - Add: `OPENAI_API_KEY=sk-your-key-here`
   - Save and re-sync

3. **Supported Models:**
   - `gpt-4-turbo` (default, recommended)
   - `gpt-4`
   - `gpt-3.5-turbo`

## ⚠️ Known Limitations

1. **Wake Word Detection**: True always-on wake-word detection is not implemented (requires dedicated wake-word engine like Porcupine)
2. **Background Service**: Background listening service is not active (requires complex foreground service setup)
3. **Web Search**: Web search is disabled by default (requires external search API integration)
4. **Local Speech Recognition**: Uses Android's built-in speech recognizer (requires Google Speech Recognizer service)
5. **Storage Permissions**: Not requested (app doesn't require file access)

## 🎯 Next Steps / Customization

### Change AI Model
Edit `gradle.properties`:
```properties
OPENAI_MODEL=gpt-3.5-turbo
```

### Change Theme Colors
Edit `app/src/main/res/values/colors.xml`:
```xml
<color name="primary_red">#YourColorHere</color>
```

### Add Web Search
Integrate a search API (Google Custom Search, Bing, etc.) in `WebSearchManager.kt`

### Enable Wake Word
Integrate Porcupine SDK or similar in `WakeWordManager.kt`

## 📞 Support

**Common Issues:**
- Microphone not working? → Check Android Settings > App Permissions > Microphone
- API errors? → Verify API key validity and billing account
- No TTS voice? → Install Google Text-to-Speech from Play Store

## 📜 License

ULTRON is a demonstration project for educational purposes.

## 🙏 Credits

- **OpenAI API** for GPT integration
- **Android Framework** for native APIs
- **AndroidIDE** for on-device development

---

**ULTRON v1.0** - Built for AndroidIDE | Last Updated: 2026-10-07
